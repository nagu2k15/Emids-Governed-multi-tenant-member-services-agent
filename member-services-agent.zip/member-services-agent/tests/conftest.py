"""Fixtures. Tests that need the supplied pack skip cleanly when MSA_PACK_DIR is not set / invalid."""
from __future__ import annotations

import os
import sys
from dataclasses import replace
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from msagent.bootstrap import build_service          # noqa: E402
from msagent.config import Config                    # noqa: E402
from msagent.evaluation import start_mock            # noqa: E402


@pytest.fixture(scope="session")
def pack():
    p = Path(os.environ.get("MSA_PACK_DIR", "pack"))
    if not (p / "mock_services" / "server.py").exists():
        pytest.skip("supplied pack not found (set MSA_PACK_DIR)")
    return p


@pytest.fixture()
def mock(pack):
    """A fresh mock per test: grievance counters and quotas start clean."""
    proc, url = start_mock(pack)
    yield url
    proc.kill()


@pytest.fixture()
def svc(pack, mock, tmp_path):
    cfg = replace(Config.from_env(), pack_dir=pack, mock_url=mock, trace_dir=tmp_path / "traces")
    return build_service(cfg)
