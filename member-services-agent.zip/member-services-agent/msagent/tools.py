"""Tool implementations. They are only ever invoked through the Gateway.

Design rules applied here:
* No tool takes a tenant or member id from the model; both come from the bound session.
* Tools return minimum-necessary projections (no SSN/DOB/phone/email/address/name).
* Arithmetic and date logic is done here, deterministically, not by the model.
* Free text from upstream systems is neutralised (`safety.neutralise`) before it is returned.
"""
from __future__ import annotations

import re
import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Callable

from .clients import ApiError, DirectoryClient, MemberServicesClient
from .config import Config
from .kb import KnowledgeBase, family_amount, individual_amount
from .safety import neutralise, scrub
from .session import PROPOSED, Proposal, Session, new_id

CATEGORIES = ["billing", "quality_of_care", "access", "customer_service", "other"]


class ToolError(Exception):
    """A tool-level failure that is safe to show the model."""


class ClaimsCache:
    """Tenant+member keyed cache of a member's claims with in-flight de-duplication."""

    def __init__(self, ttl: float):
        self.ttl, self._e, self._lock = ttl, {}, threading.Lock()
        self._pool = ThreadPoolExecutor(max_workers=8, thread_name_prefix="claims")

    def get(self, key: tuple, loader: Callable[[], list]) -> list:
        return self._future(key, loader).result()

    def prefetch(self, key: tuple, loader):
        self._future(key, loader)

    def peek(self, key: tuple):
        with self._lock:
            e = self._e.get(key)
        if e and e[1].done() and not e[1].exception() and time.time() - e[0] < self.ttl:
            return e[1].result()
        return None

    def _future(self, key, loader) -> Future:
        with self._lock:
            e = self._e.get(key)
            if e and time.time() - e[0] < self.ttl and not (e[1].done() and e[1].exception()):
                return e[1]
            fut = self._pool.submit(loader)
            self._e[key] = (time.time(), fut)
            return fut

    def drop(self, key):
        with self._lock:
            self._e.pop(key, None)


class Platform:
    """Process-wide shared resources. Everything tenant-specific is keyed by tenant."""

    def __init__(self, cfg: Config, kb: KnowledgeBase, as_of: str, tenant_names: dict[str, str]):
        self.cfg, self.kb, self.as_of, self.tenant_names = cfg, kb, as_of, tenant_names
        self.ms = {t: MemberServicesClient(cfg.mock_url, t, tok, cfg.http_timeout_s)
                   for t, tok in cfg.tokens.items()}
        self.directory = DirectoryClient(cfg.mock_url, cfg.directory_key, cfg.http_timeout_s)
        self.claims = ClaimsCache(cfg.claims_cache_ttl_s)

    @property
    def plan_year(self) -> int:
        return int(self.as_of[:4])

    def client(self, tenant: str) -> MemberServicesClient:
        return self.ms[tenant]


@dataclass
class Tool:
    name: str
    description: str
    schema: dict
    handler: Callable
    writes: bool = False


# --------------------------------------------------------------------------- helpers
def _claims_key(s: Session):
    return (s.tenant, s.member_id)


def load_claims(p: Platform, s: Session) -> list[dict]:
    def loader():
        rows = p.client(s.tenant).all_claims(s.member_id)
        # defence in depth: the platform must only return this member's claims
        return [c for c in rows if c.get("member_id") == s.member_id]
    return p.claims.get(_claims_key(s), loader)


def prefetch_claims(p: Platform, s: Session):
    if p.cfg.prefetch_claims and s.member_status == "ok":
        p.claims.prefetch(_claims_key(s), lambda: [
            c for c in p.client(s.tenant).all_claims(s.member_id) if c.get("member_id") == s.member_id])


def claim_view(c: dict) -> dict:
    mr = c.get("member_responsibility") or {}
    notes, flagged = [], False
    for n in c.get("notes") or []:
        txt, f = neutralise(n.get("text", ""))
        flagged |= f
        notes.append({"author": n.get("author"), "date": n.get("date"), "text": txt})
    v = {"claim_id": c["claim_id"], "service_date": c["service_date"], "processed_date": c.get("processed_date"),
         "status": c["status"], "provider": (c.get("provider") or {}).get("name"),
         "service": (c.get("service") or {}).get("description"), "service_code": (c.get("service") or {}).get("code"),
         "billed_amount": c.get("billed_amount"), "allowed_amount": c.get("allowed_amount"),
         "plan_paid": c.get("plan_paid"),
         "member_owes": {"deductible": mr.get("deductible", 0), "copay": mr.get("copay", 0),
                         "coinsurance": mr.get("coinsurance", 0),
                         "total": round(sum(mr.get(k, 0) or 0 for k in ("deductible", "copay", "coinsurance")), 2)},
         "denial": c.get("denial"), "notes": notes}
    if flagged:
        v["notes_warning"] = "Some note text was withheld because it contained instruction-like content."
    return v


def _d(s: str) -> date:
    return date.fromisoformat(s)


def _kb_days(p: Platform, tenant: str, topic: str) -> int:
    row = p.kb.rule(tenant, topic)
    m = row and re.search(r"(\d+)\s+calendar days", row.text)
    if not m:
        raise ToolError(f"Rule '{topic}' is not available in the plan documents.")
    return int(m.group(1))


# --------------------------------------------------------------------------- handlers
def t_member_context(p: Platform, s: Session, a: dict) -> dict:
    return dict(s.coverage)


def t_accumulators(p: Platform, s: Session, a: dict) -> dict:
    b = p.client(s.tenant).benefits(s.member_id)
    acc = b.get("accumulators") or {}
    year = acc.get("plan_year", p.plan_year)
    pc = s.member["product_code"]

    def row(prefix):
        return p.kb.benefit_row(s.tenant, pc, year, prefix)
    ded, oop, pt = row("Deductible"), row("Out-of-pocket maximum"), row("Physical therapy visit limit")
    out = {"plan_year": year, "as_of": acc.get("as_of"), "coverage_status": b["coverage_status"],
           "scope": "individual, in-network", "product": s.coverage.get("product")}
    if ded and "deductible_met_individual" in acc:
        lim = individual_amount(ded.cells[1])
        out["deductible"] = {"limit": lim, "family_limit": family_amount(ded.cells[1]),
                             "met": acc["deductible_met_individual"],
                             "remaining": round(max(lim - acc["deductible_met_individual"], 0), 2)}
    if oop and "out_of_pocket_met_individual" in acc:
        lim = individual_amount(oop.cells[1])
        out["out_of_pocket_max"] = {"limit": lim, "family_limit": family_amount(oop.cells[1]),
                                    "met": acc["out_of_pocket_met_individual"],
                                    "remaining": round(max(lim - acc["out_of_pocket_met_individual"], 0), 2)}
    if pt and "physical_therapy_visits_used" in acc:
        m = re.search(r"(\d+)\s+visits", pt.cells[1])
        if m:
            lim = int(m.group(1))
            out["physical_therapy"] = {"limit": lim, "used": acc["physical_therapy_visits_used"],
                                       "remaining": max(lim - acc["physical_therapy_visits_used"], 0)}
    return out


def t_search_docs(p: Platform, s: Session, a: dict) -> dict:
    year = a.get("plan_year") or p.plan_year
    hits = p.kb.search(s.tenant, a["query"], product_code=s.member["product_code"], plan_year=year,
                       top_k=int(a.get("top_k", 3)))
    for c, _ in hits:                      # belt and braces: the index is already per tenant
        if c.tenant != s.tenant:
            raise ToolError("isolation violation in retrieval")
    return {"plan_year": year, "member_product": s.coverage.get("product"),
            "results": [c.public(sc) for c, sc in hits]}


def t_get_claim(p: Platform, s: Session, a: dict) -> dict:
    cid = a["claim_id"]
    c = next((x for x in (p.claims.peek(_claims_key(s)) or []) if x["claim_id"] == cid), None)
    c = c or p.client(s.tenant).claim(cid)
    if not c or c.get("member_id") != s.member_id:
        # Same answer whether the claim does not exist or belongs to someone else: no oracle.
        return {"found": False, "message": "No claim with that id for this member."}
    return {"found": True, "claim": claim_view(c)}


def t_search_claims(p: Platform, s: Session, a: dict) -> dict:
    rows = load_claims(p, s)
    if a.get("status"):
        rows = [c for c in rows if c["status"] == a["status"]]
    if a.get("service_date"):
        rows = [c for c in rows if c["service_date"] == a["service_date"]]
    if a.get("date_from"):
        rows = [c for c in rows if c["service_date"] >= a["date_from"]]
    if a.get("date_to"):
        rows = [c for c in rows if c["service_date"] <= a["date_to"]]
    if a.get("text"):
        words = [w for w in re.findall(r"[a-z0-9]+", a["text"].lower()) if len(w) > 2]
        rows = [c for c in rows if all(w in (c["service"]["description"] + " " + c["place_of_service"]).lower()
                                       for w in words)]
    counts: dict[str, int] = {}
    for c in rows:
        counts[c["status"]] = counts.get(c["status"], 0) + 1
    return {"total_matching": len(rows), "counts_by_status": counts,
            "claims": [claim_view(c) for c in rows[:int(a.get("limit", 5))]]}


def t_grievances(p: Platform, s: Session, a: dict) -> dict:
    rows = [g for g in p.client(s.tenant).grievances(s.member_id) if g.get("member_id") == s.member_id]
    return {"grievances": [{"grievance_id": g["grievance_id"], "category": g["category"], "status": g["status"],
                            "received_date": g["received_date"], "resolved_date": g.get("resolved_date")}
                           for g in rows]}


def t_check_deadline(p: Platform, s: Session, a: dict) -> dict:
    today = _d(p.as_of)
    if a["kind"] == "appeal":
        r = t_get_claim(p, s, {"claim_id": a["reference_id"]})
        if not r["found"]:
            return {"found": False, "message": "No claim with that id for this member."}
        c = r["claim"]
        if c["status"] != "DENIED" or not c["processed_date"]:
            return {"found": True, "applicable": False, "claim_status": c["status"],
                    "message": "Only a denied claim has an appeal window."}
        days = _kb_days(p, s.tenant, "Claim appeal filing window")
        dl = _d(c["processed_date"]) + timedelta(days=days)
        return {"found": True, "applicable": True, "claim_id": c["claim_id"], "denial_notice_date": c["processed_date"],
                "window_days": days, "deadline": dl.isoformat(), "within_window": today <= dl,
                "days_remaining": (dl - today).days, "as_of": p.as_of, "denial": c["denial"]}
    g = next((x for x in t_grievances(p, s, {})["grievances"] if x["grievance_id"] == a["reference_id"]), None)
    if not g:
        return {"found": False, "message": "No grievance with that id for this member."}
    days = _kb_days(p, s.tenant, "Grievance resolution timeframe")
    dl = _d(g["received_date"]) + timedelta(days=days)
    open_ = g["status"] != "RESOLVED"
    return {"found": True, "grievance_id": g["grievance_id"], "status": g["status"], "received_date": g["received_date"],
            "resolution_days": days, "deadline": dl.isoformat(), "past_deadline": open_ and today > dl,
            "days_remaining": (dl - today).days if open_ else None, "resolved_date": g.get("resolved_date"),
            "as_of": p.as_of}


def t_verify_identity(p: Platform, s: Session, a: dict) -> dict:
    if not a.get("ssn_last4") and not a.get("dob"):
        raise ToolError("Provide ssn_last4 and/or dob.")
    if s.identity_attempts >= 3:
        return {"locked": True, "message": "Too many verification attempts on this call. Escalate per policy."}
    s.identity_attempts += 1
    out = {"locked": False}
    if a.get("ssn_last4"):
        out["ssn_last4_match"] = (s.member["ssn"] or "").replace("-", "")[-4:] == a["ssn_last4"]
    if a.get("dob"):
        out["dob_match"] = s.member["dob"] == a["dob"]
    return out


def t_find_providers(p: Platform, s: Session, a: dict) -> dict:
    net = s.member["network_id"]
    zip_ = a.get("zip") or s.member["address"]["zip"]
    # Only the specialty goes in `query`. Member identifiers are never sent to the vendor.
    body = p.directory.search(query=a["specialty"], specialty=a["specialty"], zip=zip_, network_id=net, limit=20)
    out = []
    for r in body.get("results", []):
        if net not in r.get("networks", []) or r["address"]["zip"][:3] != zip_[:3]:
            continue                      # do not trust vendor-side filtering
        name, f1 = neutralise(r["name"])
        out.append({"name": name, "npi": r["npi"], "specialty": r["specialty"], "practice": neutralise(r["practice"])[0],
                    "city": r["address"]["city"], "zip": r["address"]["zip"], "phone": r.get("phone"),
                    "accepting_new_patients": r.get("accepting_new_patients"), "network": net})
    out.sort(key=lambda x: (not x["accepting_new_patients"], x["name"]))
    return {"network": net, "searched_zip_area": zip_[:3] + "xx", "providers": out[:5], "total_in_network": len(out)}


def t_propose_grievance(p: Platform, s: Session, a: dict) -> dict:
    desc = scrub(a["description"].strip(), s.sensitive_values())
    if not desc:
        raise ToolError("description is required")
    for old in s.proposals.values():
        if old.status == PROPOSED:
            old.status = "CANCELLED"      # superseded
    prop = Proposal(new_id(), a["category"], desc[:2000], bool(a.get("expedite_requested", False)),
                    a.get("expedite_reason", ""), s.turn_no)
    s.proposals[prop.id] = prop
    dup = [g for g in t_grievances(p, s, {})["grievances"]
           if g["category"] == prop.category and g["status"] != "RESOLVED"]
    out = {**prop.view(), "awaiting": "rep confirmation after reading the summary to the member",
           "note": "NOT FILED. The system files only after the rep explicitly confirms in the next message."}
    if dup:
        out["possible_duplicate_of"] = [g["grievance_id"] for g in dup]
    if prop.expedite_requested:
        out["expedite_note"] = ("Expedited handling is decided by the plan's clinical staff; "
                                "this is recorded as a request only.")
    return out


# --------------------------------------------------------------------------- registry
def _str(maxlen=200, **kw):
    return {"type": "string", "maxLength": maxlen, **kw}


def build_tools(p: Platform) -> dict[str, Tool]:
    H = lambda f: (lambda s, a: f(p, s, a))   # noqa: E731
    T = [
        Tool("get_member_context",
             "Coverage summary of the member on this call: plan, product, coverage status and dates. Call first.",
             {"type": "object", "properties": {}, "additionalProperties": False}, H(t_member_context)),
        Tool("get_accumulators",
             "Deductible, out-of-pocket maximum and physical-therapy visits: limit, met/used and REMAINING, "
             "already computed for the member's plan year. Use for any 'how much is left' question.",
             {"type": "object", "properties": {}, "additionalProperties": False}, H(t_accumulators)),
        Tool("search_plan_docs",
             "Search the member's plan documents (benefit summaries, member services guide, claim codes). "
             "Scoped to the member's tenant and product. Use plan_year 2027 for questions about the next plan year.",
             {"type": "object", "properties": {"query": _str(300), "plan_year": {"type": "integer"},
                                               "top_k": {"type": "integer"}},
              "required": ["query"], "additionalProperties": False}, H(t_search_docs)),
        Tool("get_claim", "Look up one claim of this member by claim id.",
             {"type": "object", "properties": {"claim_id": _str(20, pattern=r"^C\d{10}$")},
              "required": ["claim_id"], "additionalProperties": False}, H(t_get_claim)),
        Tool("search_claims",
             "Filter this member's claims (all pages are read for you). Returns totals and up to 5 newest matches. "
             "Dates are YYYY-MM-DD service dates.",
             {"type": "object", "properties": {
                 "status": {"type": "string", "enum": ["IN_PROCESS", "PENDED", "PAID", "DENIED"]},
                 "service_date": _str(10, pattern=r"^\d{4}-\d{2}-\d{2}$"), "date_from": _str(10, pattern=r"^\d{4}-\d{2}-\d{2}$"),
                 "date_to": _str(10, pattern=r"^\d{4}-\d{2}-\d{2}$"), "text": _str(80), "limit": {"type": "integer"}},
              "additionalProperties": False}, H(t_search_claims)),
        Tool("get_grievances", "Grievances on file for this member.",
             {"type": "object", "properties": {}, "additionalProperties": False}, H(t_grievances)),
        Tool("check_deadline",
             "Deterministic deadline check. kind=appeal with a claim id (180-day window from denial notice) or "
             "kind=grievance with a grievance id (plan resolution timeframe). Returns the deadline and yes/no.",
             {"type": "object", "properties": {"kind": {"type": "string", "enum": ["appeal", "grievance"]},
                                               "reference_id": _str(20)},
              "required": ["kind", "reference_id"], "additionalProperties": False}, H(t_check_deadline)),
        Tool("verify_identity",
             "Check a caller-supplied last four SSN digits and/or date of birth against the record. "
             "Returns match booleans only. The full SSN is never available.",
             {"type": "object", "properties": {"ssn_last4": _str(4, pattern=r"^\d{4}$"),
                                               "dob": _str(10, pattern=r"^\d{4}-\d{2}-\d{2}$")},
              "additionalProperties": False}, H(t_verify_identity)),
        Tool("find_providers",
             "Find in-network providers of a specialty near the member's home ZIP (looked up server-side).",
             {"type": "object", "properties": {"specialty": _str(60), "zip": _str(5, pattern=r"^\d{5}$")},
              "required": ["specialty"], "additionalProperties": False}, H(t_find_providers)),
        Tool("propose_grievance",
             "Prepare a grievance for the rep to confirm. Does NOT file it. Filing happens only after the rep "
             "confirms in a later message. One grievance per issue. Expedited is a request only.",
             {"type": "object", "properties": {"category": {"type": "string", "enum": CATEGORIES},
                                               "description": _str(2000),
                                               "expedite_requested": {"type": "boolean"},
                                               "expedite_reason": _str(300)},
              "required": ["category", "description"], "additionalProperties": False}, H(t_propose_grievance)),
    ]
    return {t.name: t for t in T}
