"""Tenant-partitioned retrieval over plan documents.

* One index per tenant; a search can only ever see the caller's tenant (no shared index to filter).
* A document is quarantined (indexed nowhere) if its front-matter tenant does not match the folder
  it sits in, or if front-matter is incomplete: provenance is unclear, so fail closed.
* Instruction-like lines inside documents are dropped at load time (documents are data).
* Chunks are table rows / bullets / paragraphs, so a query returns the exact benefit row.
"""
from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

from .safety import looks_like_injection

REQUIRED_FM = ("tenant", "plan_year", "effective_date", "product_code", "product")

SYNONYMS = {
    "er": "emergency room", "emergency": "emergency room", "video": "telehealth", "virtual": "telehealth",
    "pt": "physical therapy", "therapy": "physical therapy", "generic": "generic drugs tier 1",
    "brand": "brand drugs", "rx": "drugs", "prescription": "drugs", "pharmacy": "drugs",
    "oop": "out-of-pocket maximum", "doctor": "primary care", "pcp": "primary care",
    "mri": "advanced imaging", "ct": "advanced imaging", "scan": "advanced imaging",
    "hospital": "inpatient hospital", "surgery": "outpatient surgery", "mental": "behavioral health",
    "therapist": "behavioral health", "counseling": "behavioral health",
}
STOP = {"the", "a", "an", "of", "is", "what", "does", "do", "for", "to", "and", "in", "how", "much",
        "member", "this", "that", "pay", "cost", "costs", "with", "at", "on", "will", "be"}


def _tok(s: str) -> list[str]:
    return [w[:-1] if len(w) > 3 and w.endswith("s") else w for w in re.findall(r"[a-z0-9$%]+", s.lower())]


@dataclass(frozen=True)
class Chunk:
    tenant: str
    doc: str
    plan_year: int
    effective_date: str
    product_code: str
    product: str
    kind: str          # benefit_row | rule_row | code_row | bullet | para
    title: str
    text: str
    cells: tuple = ()  # (label, in_network, out_of_network) for benefit rows

    def public(self, score: float | None = None) -> dict:
        d = {"product": self.product, "plan_year": self.plan_year, "effective_date": self.effective_date,
             "doc": self.doc, "title": self.title, "text": self.text}
        if score is not None:
            d["score"] = round(score, 2)
        return d


def parse_front_matter(raw: str) -> tuple[dict, str]:
    m = re.match(r"\A---\s*\n(.*?)\n---\s*\n", raw, re.S)
    if not m:
        return {}, raw
    fm = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            fm[k.strip()] = v.strip()
    return fm, raw[m.end():]


class KnowledgeBase:
    def __init__(self, kb_dir: Path):
        self.chunks: dict[str, list[Chunk]] = {}
        self.quarantined: list[dict] = []
        self.dropped_lines: list[dict] = []
        self._df: dict[str, Counter] = {}
        self._load(Path(kb_dir))

    # ------------------------------------------------------------ loading
    def _load(self, kb_dir: Path):
        if not kb_dir.exists():
            return
        for tdir in sorted(p for p in kb_dir.iterdir() if p.is_dir()):
            self.chunks.setdefault(tdir.name, [])
            for f in sorted(tdir.glob("*.md")):
                fm, body = parse_front_matter(f.read_text(encoding="utf-8"))
                rel = f"{tdir.name}/{f.name}"
                if any(k not in fm for k in REQUIRED_FM):
                    self.quarantined.append({"doc": rel, "reason": "incomplete front-matter"})
                    continue
                if fm["tenant"] != tdir.name:
                    self.quarantined.append({"doc": rel, "reason":
                                             f"front-matter tenant '{fm['tenant']}' != folder '{tdir.name}'"})
                    continue
                try:
                    year = int(fm["plan_year"])
                except ValueError:
                    self.quarantined.append({"doc": rel, "reason": "bad plan_year"})
                    continue
                self.chunks[tdir.name].extend(self._chunk(tdir.name, rel, fm, year, body))
        for t, cs in self.chunks.items():
            df = Counter()
            for c in cs:
                df.update(set(_tok(c.title + " " + c.text)))
            self._df[t] = df

    def _chunk(self, tenant, doc, fm, year, body) -> list[Chunk]:
        base = dict(tenant=tenant, doc=doc, plan_year=year, effective_date=fm["effective_date"],
                    product_code=fm["product_code"], product=fm["product"])
        out, header, section = [], None, ""
        for line in body.splitlines():
            s = line.strip()
            if not s or s.startswith("# "):
                header = header if s else header
                continue
            if looks_like_injection(s):
                self.dropped_lines.append({"doc": doc, "line": s[:80]})
                continue
            if s.startswith("## "):
                section, header = s[3:], None
                continue
            if s.startswith("|"):
                cells = [c.strip() for c in s.strip("|").split("|")]
                if all(re.fullmatch(r":?-+:?", c) for c in cells):
                    continue
                if header is None:
                    header = cells
                    continue
                label = cells[0]
                kind = "benefit_row" if len(cells) == 3 and "network" in header[1].lower() else (
                    "code_row" if header[0].lower() in ("carc", "status") else "rule_row")
                text = "; ".join(f"{h}: {c}" for h, c in zip(header, cells))
                out.append(Chunk(**base, kind=kind, title=label, text=text,
                                 cells=tuple(cells) if kind == "benefit_row" else ()))
            elif s.startswith("- "):
                out.append(Chunk(**base, kind="bullet", title=section or "note", text=s[2:]))
            else:
                out.append(Chunk(**base, kind="para", title=section or "overview", text=s))
        return out

    # ------------------------------------------------------------ search
    def search(self, tenant: str, query: str, *, product_code: str | None = None,
               plan_year: int | None = None, top_k: int = 4) -> list[tuple[Chunk, float]]:
        cands = [c for c in self.chunks.get(tenant, [])
                 if (product_code is None or c.product_code in (product_code, "ALL"))
                 and (plan_year is None or c.product_code == "ALL" or c.plan_year == plan_year)]
        qt = []
        for w in re.findall(r"[a-z0-9$%-]+", query.lower()):
            if w in STOP:
                continue
            qt.extend(_tok(SYNONYMS.get(w, w)))
            if w in SYNONYMS:
                qt.extend(_tok(w))
        qt = [w for w in qt if w not in STOP]
        df, n = self._df.get(tenant, Counter()), max(len(self.chunks.get(tenant, [])), 1)
        scored = []
        for c in cands:
            tt, bt = Counter(_tok(c.title)), Counter(_tok(c.text))
            score = 0.0
            for w in set(qt):
                idf = math.log(1 + (n - df.get(w, 0) + 0.5) / (df.get(w, 0) + 0.5))
                score += idf * (2.0 * min(tt[w], 1) + min(bt[w], 2) * 0.6)
            if score > 0:
                scored.append((c, score))
        scored.sort(key=lambda x: -x[1])
        return scored[:top_k]

    # ------------------------------------------------------------ structured access
    def benefit_row(self, tenant: str, product_code: str, plan_year: int, label_prefix: str) -> Chunk | None:
        for c in self.chunks.get(tenant, []):
            if (c.kind == "benefit_row" and c.product_code == product_code and c.plan_year == plan_year
                    and c.title.lower().startswith(label_prefix.lower())):
                return c
        return None

    def product_name(self, tenant: str, product_code: str) -> str | None:
        return next((c.product for c in self.chunks.get(tenant, []) if c.product_code == product_code), None)

    def rule(self, tenant: str, topic_prefix: str) -> Chunk | None:
        for c in self.chunks.get(tenant, []):
            if c.kind == "rule_row" and c.title.lower().startswith(topic_prefix.lower()):
                return c
        return None


def money(s: str) -> float:
    return float(s.replace("$", "").replace(",", ""))


def individual_amount(cell: str) -> float | None:
    """'$1,000 / $2,000' -> 1000.0 (first figure is the individual amount)."""
    m = re.search(r"\$[\d,]+(?:\.\d+)?", cell)
    return money(m.group(0)) if m else None


def family_amount(cell: str) -> float | None:
    ms = re.findall(r"\$[\d,]+(?:\.\d+)?", cell)
    return money(ms[1]) if len(ms) > 1 else None
