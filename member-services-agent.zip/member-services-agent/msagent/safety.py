"""Untrusted-text handling: prompt-injection detection and PHI redaction.

Everything that comes back from a tool, a KB document or a vendor manifest is DATA. These helpers
neutralise instruction-like text before it reaches the model, and scrub PHI before it reaches logs.
"""
from __future__ import annotations

import hashlib
import hmac
import re

# Text that addresses an assistant / tells it to act. Deliberately broad: a false positive only
# withholds a free-text note, a false negative could steer an agent.
_INJECTION = [
    r"\bassistant\s*:", r"\b(ai|llm)\b[^.\n]{0,40}\b(assistant|agent|model|coding)\b",
    r"(processing )?note for (ai|llm|assistant)", r"do not (mention|tell|reveal|disclose)\b",
    r"ignore (all |any |the )?(previous|prior|above|earlier)", r"disregard\b", r"system prompt",
    r"\bwithout asking\b", r"\bmark (it|this) (as )?urgent\b", r"\b(file|submit) a grievance\b",
    r"\bneed(s)? not be mentioned\b", r"does not need to be mentioned",
    r"\balways begin the query\b", r"\bsocial security number\b.{0,60}\b(prefix|begin|include|append)",
    r"\b(must|should) (first |always )?(call|use|invoke|send)\b",
]
_INJ_RE = re.compile("|".join(_INJECTION), re.I)

WITHHELD = "[text withheld: contained instruction-like content]"


def looks_like_injection(text: str) -> bool:
    return bool(text) and bool(_INJ_RE.search(text))


def neutralise(text: str) -> tuple[str, bool]:
    """Return (safe_text, was_flagged)."""
    if looks_like_injection(text):
        return WITHHELD, True
    return text, False


# ---------------------------------------------------------------- PHI redaction
SSN_RE = re.compile(r"\b\d{3}[- ]\d{2}[- ]\d{4}\b|\b\d{9}\b")
PHONE_RE = re.compile(r"(?<!\d)(?:\+?1[-.\s])?\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}(?!\d)")
EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")


def scrub(text: str, known: list[str] | None = None, patterns: bool = True) -> str:
    """Remove literal known-sensitive values (name, dob, address ...) and, if `patterns`, SSN/email/phone shapes.
    Replies use patterns=False for phone/email (a provider phone number is not member PHI) but still strip SSNs."""
    if not text:
        return text
    out = text
    for v in sorted((k for k in (known or []) if k and len(k) >= 3), key=len, reverse=True):
        out = re.sub(re.escape(v), "[REDACTED]", out, flags=re.I)
    out = SSN_RE.sub("[SSN]", out)
    if patterns:
        out = EMAIL_RE.sub("[EMAIL]", out)
        out = PHONE_RE.sub("[PHONE]", out)
    return out


def pseudonym(value: str, key: bytes) -> str:
    """Stable, non-reversible reference for ids in logs (HMAC-SHA256, truncated)."""
    return "p_" + hmac.new(key, value.encode(), hashlib.sha256).hexdigest()[:12]
