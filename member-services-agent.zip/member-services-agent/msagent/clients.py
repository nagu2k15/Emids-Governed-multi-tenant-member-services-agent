"""HTTP clients for the member-services APIs and the third-party directory (stdlib only).

A MemberServicesClient is bound to ONE tenant at construction: it holds only that tenant's token and
builds every URL with that tenant, so a handler cannot reach another tenant even by mistake.
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request


class ApiError(Exception):
    def __init__(self, status: int, code: str = "", message: str = "", retry_after: float | None = None):
        super().__init__(f"{status} {code}: {message}")
        self.status, self.code, self.message, self.retry_after = status, code, message, retry_after


def _request(method, url, headers, body=None, timeout=10.0):
    data = json.dumps(body).encode() if body is not None else None
    h = {"Accept": "application/json", "Connection": "close", **headers}
    if data is not None:
        h["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            return r.status, dict(r.headers), (json.loads(raw) if raw else None)
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            j = json.loads(raw) if raw else {}
        except ValueError:
            j = {}
        ra = e.headers.get("Retry-After")
        raise ApiError(e.code, j.get("error", ""), j.get("message", ""), float(ra) if ra else None)
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise ApiError(0, "network", str(e))


class MemberServicesClient:
    def __init__(self, base_url: str, tenant: str, token: str, timeout: float = 10.0,
                 max_retries: int = 3, sleep=time.sleep):
        self.base, self.tenant, self._token = base_url.rstrip("/"), tenant, token
        self.timeout, self.max_retries, self._sleep = timeout, max_retries, sleep

    def _call(self, method, path, body=None):
        url = f"{self.base}/tenants/{self.tenant}{path}"
        headers = {"Authorization": f"Bearer {self._token}"}
        attempt = 0
        while True:
            try:
                return _request(method, url, headers, body, self.timeout)
            except ApiError as e:
                attempt += 1
                if e.status not in (0, 429, 502, 503, 504) or attempt > self.max_retries:
                    raise
                self._sleep(min(e.retry_after or 0.5 * attempt, 5.0))

    # ---- reads
    def get_member(self, member_id):
        try:
            return self._call("GET", f"/members/{urllib.parse.quote(member_id)}")[2]
        except ApiError as e:
            if e.status == 404:
                return None
            raise

    def benefits(self, member_id):
        return self._call("GET", f"/members/{urllib.parse.quote(member_id)}/benefits")[2]

    def claim(self, claim_id):
        try:
            return self._call("GET", f"/claims/{urllib.parse.quote(claim_id)}")[2]
        except ApiError as e:
            if e.status == 404:
                return None
            raise

    def all_claims(self, member_id, fanout: int = 3):
        """All claims, newest first. Pages hold at most 5 and each call costs ~1.5 s, so fetch `fanout` pages
        concurrently using the documented `cursor` parameter, then continue the same way until `next` is null.
        Latency for a member with n claims is ceil(n / (5 * fanout)) calls deep instead of ceil(n / 5)."""
        from concurrent.futures import ThreadPoolExecutor
        mid, rows, cursor = urllib.parse.quote(member_id), [], 0
        with ThreadPoolExecutor(max_workers=fanout) as pool:
            while True:
                offsets = [cursor + 5 * i for i in range(fanout)]
                pages = list(pool.map(lambda c: self._call("GET", f"/members/{mid}/claims?page_size=5&cursor={c}")[2], offsets))
                for pg in pages:
                    rows.extend(pg["data"])
                if not pages[-1].get("next"):
                    break
                cursor += 5 * fanout
        seen, out = set(), []
        for c in sorted(rows, key=lambda c: (c["service_date"], c["claim_id"]), reverse=True):
            if c["claim_id"] not in seen:
                seen.add(c["claim_id"])
                out.append(c)
        return out

    def grievances(self, member_id):
        return self._call("GET", f"/members/{urllib.parse.quote(member_id)}/grievances")[2]["data"]

    # ---- write: single attempt; the caller owns retry semantics because of idempotency
    def create_grievance(self, member_id, payload, idempotency_key):
        st, hdr, body = _request(
            "POST", f"{self.base}/tenants/{self.tenant}/members/{urllib.parse.quote(member_id)}/grievances",
            {"Authorization": f"Bearer {self._token}", "Idempotency-Key": idempotency_key},
            payload, self.timeout)
        return st, body, hdr.get("Idempotent-Replayed") == "true"


class DirectoryClient:
    def __init__(self, base_url: str, api_key: str, timeout: float = 10.0):
        self.base, self._key, self.timeout = base_url.rstrip("/") + "/directory/v3", api_key, timeout

    def search(self, *, query: str, specialty=None, zip=None, network_id=None, limit=10):
        params = {"query": query, "limit": limit}
        for k, v in (("specialty", specialty), ("zip", zip), ("network_id", network_id)):
            if v:
                params[k] = v
        return _request("GET", f"{self.base}/providers?{urllib.parse.urlencode(params)}",
                        {"X-Api-Key": self._key}, None, self.timeout)[2]
