"""Command line: interactive chat for one tenant/member, or start the HTTP API.

    python -m msagent chat --tenant plan_a --member M749817
    python -m msagent serve --port 8080
"""
from __future__ import annotations

import argparse
import json

from .bootstrap import build_service
from .config import Config


def main(argv=None):
    ap = argparse.ArgumentParser(prog="msagent")
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("chat")
    c.add_argument("--tenant", required=True)
    c.add_argument("--member", required=True)
    c.add_argument("--rep", default="cli-rep")
    c.add_argument("--show-trace", action="store_true")
    s = sub.add_parser("serve")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=8080)
    args = ap.parse_args(argv)
    cfg = Config.from_env()
    svc = build_service(cfg)
    if args.cmd == "serve":
        from .api import load_reps, serve
        reps = load_reps(cfg)
        if not reps:
            print("warning: no MSA_REPS_FILE; every request will be 401")
        return serve(svc, reps, args.host, args.port)
    if args.tenant not in cfg.tokens:
        raise SystemExit(f"unknown tenant {args.tenant}; configured: {sorted(cfg.tokens)}")
    s = svc.create_conversation(args.tenant, args.rep, args.member)
    print(f"[{args.tenant} / {args.member}] provider={svc.llm.name}. Empty line to quit.")
    while True:
        try:
            text = input("rep> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not text:
            break
        r = svc.turn(s, text)
        print(f"\nassistant> {r['reply']}\n   [{r['kind']}, {r['latency_s']}s, steps={r['budget']['steps']}]\n")
    if args.show_trace:
        print(json.dumps(s.trace.events, indent=1))


if __name__ == "__main__":
    main()
