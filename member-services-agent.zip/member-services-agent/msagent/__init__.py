"""Governed multi-tenant member-services agent (vertical slice)."""
__version__ = "0.1.0"
