"""The tool gateway. EVERY tool call, and the only write path, goes through here.

Pipeline for a model-initiated call:
  1. known tool?                     (unknown -> deny)
  2. session bound to a real member? (else deny)
  3. budget (steps / cost / latency) (exhausted -> deny)
  4. schema validation               (unknown args such as tenant/member_id -> deny)
  5. execute handler (tenant-bound clients, member-bound session)
  6. isolation canary on the output  (another tenant's name in the payload -> block + alert)
  7. size cap, trace (args + result SHAPE only, scrubbed)
Writes are not model-callable at all: `execute_confirmed` is invoked by the orchestrator only after the
rep's own message has confirmed a specific stored proposal.
"""
from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import dataclass

from .budget import BudgetExceeded
from .clients import ApiError
from .session import CANCELLED, CONFIRMED, EXECUTED, FAILED, PROPOSED, UNKNOWN, Session
from .tools import Platform, Tool, ToolError, build_tools

MAX_RESULT_CHARS = 6000
SAFE_LOG_KEYS = {"found", "status", "total_matching", "coverage_status", "proposal_id", "plan_year",
                 "locked", "ssn_last4_match", "dob_match", "within_window", "past_deadline", "applicable",
                 "total_in_network", "applicable", "network"}


@dataclass
class ToolResult:
    ok: bool
    content: dict
    decision: str = "allow"      # allow | deny | error | blocked
    reason: str = ""

    def text(self) -> str:
        s = json.dumps(self.content, separators=(",", ":"))
        return s if len(s) <= MAX_RESULT_CHARS else s[:MAX_RESULT_CHARS] + '..."truncated"'


def validate(schema: dict, args) -> str | None:
    """Minimal JSON-schema subset: object, required, additionalProperties, type, enum, maxLength, pattern."""
    if not isinstance(args, dict):
        return "arguments must be an object"
    props = schema.get("properties", {})
    for k in args:
        if k not in props:
            return (f"unknown argument '{k}' (tenant and member are bound to the session and cannot be set)"
                    if k in ("tenant", "tenant_id", "member_id", "member") else f"unknown argument '{k}'")
    for k in schema.get("required", []):
        if k not in args:
            return f"missing required argument '{k}'"
    for k, v in args.items():
        sp = props[k]
        t = sp.get("type")
        if t == "string" and not isinstance(v, str):
            return f"'{k}' must be a string"
        if t == "integer" and (not isinstance(v, int) or isinstance(v, bool)):
            return f"'{k}' must be an integer"
        if t == "boolean" and not isinstance(v, bool):
            return f"'{k}' must be a boolean"
        if "enum" in sp and v not in sp["enum"]:
            return f"'{k}' must be one of {sp['enum']}"
        if isinstance(v, str):
            if len(v) > sp.get("maxLength", 10_000):
                return f"'{k}' exceeds {sp['maxLength']} characters"
            if "pattern" in sp and not re.search(sp["pattern"], v):
                return f"'{k}' has an invalid format"
    return None


def shape(content) -> dict:
    """What we log about a result: structure and non-PHI flags, never free text or values."""
    if not isinstance(content, dict):
        return {}
    out = {}
    for k, v in content.items():
        if isinstance(v, list):
            out[k] = f"list[{len(v)}]"
        elif isinstance(v, dict):
            out[k] = "object"
        elif k in SAFE_LOG_KEYS:
            out[k] = v
        else:
            out[k] = "value"
    return out


class Gateway:
    def __init__(self, platform: Platform, sleep=time.sleep):
        self.p = platform
        self.tools: dict[str, Tool] = build_tools(platform)
        self._sleep = sleep

    def specs(self) -> list[dict]:
        """Tool definitions shown to the model: OUR descriptions and schemas, never a vendor's."""
        return [{"name": t.name, "description": t.description, "input_schema": t.schema}
                for t in self.tools.values()]

    # ------------------------------------------------------------------ model-initiated calls
    def call(self, s: Session, name: str, args: dict) -> ToolResult:
        tr = s.trace
        t0 = time.monotonic()

        def finish(res: ToolResult) -> ToolResult:
            dt = time.monotonic() - t0
            s.budget.add_latency(dt)
            tr.emit("tool_call", tool=name, args=args if isinstance(args, dict) else str(args)[:200],
                    decision=res.decision, reason=res.reason, latency_ms=int(dt * 1000),
                    result=shape(res.content))
            return res

        tool = self.tools.get(name)
        if tool is None:
            return finish(ToolResult(False, {"error": f"unknown tool '{name}'"}, "deny", "unknown_tool"))
        if s.member_status != "ok":
            return finish(ToolResult(False, {"error": "no member is bound to this conversation"}, "deny", "no_member"))
        try:
            s.budget.charge_step()
        except BudgetExceeded as e:
            return finish(ToolResult(False, {"error": f"budget exceeded ({e.dimension})"}, "deny", f"budget_{e.dimension}"))
        bad = validate(tool.schema, args)
        if bad:
            return finish(ToolResult(False, {"error": bad}, "deny", "schema"))
        try:
            content = tool.handler(s, args)
        except ToolError as e:
            return finish(ToolResult(False, {"error": str(e)}, "error", "tool_error"))
        except ApiError as e:
            return finish(ToolResult(False, {"error": f"upstream unavailable ({e.status})"}, "error", f"upstream_{e.status}"))
        except Exception as e:                       # never leak internals to the model
            tr.emit("tool_exception", tool=name, error=type(e).__name__)
            return finish(ToolResult(False, {"error": "internal error"}, "error", "exception"))
        blob = json.dumps(content)
        for t, nm in self.p.tenant_names.items():
            if t != s.tenant and nm and nm.lower() in blob.lower():
                tr.emit("isolation_alert", tool=name, detail="other tenant name present in tool output")
                return finish(ToolResult(False, {"error": "output blocked by isolation policy"}, "blocked", "isolation"))
        return finish(ToolResult(True, content))

    # ------------------------------------------------------------------ the only write path
    def execute_confirmed(self, s: Session, proposal_id: str) -> dict:
        """File a grievance that the rep has confirmed. Safe to call repeatedly: exactly once."""
        tr = s.trace
        with s.lock:
            prop = s.proposals.get(proposal_id)
            if prop is None:
                tr.emit("write_denied", reason="unknown_proposal")
                return {"filed": False, "reason": "unknown_proposal"}
            if prop.status == EXECUTED:
                tr.emit("write_replayed", proposal=proposal_id)
                return {"filed": True, "replay": True, **(prop.result or {})}
            if prop.status not in (CONFIRMED, UNKNOWN):
                tr.emit("write_denied", proposal=proposal_id, reason=f"status_{prop.status}")
                return {"filed": False, "reason": f"proposal is {prop.status}, not confirmed"}
            if prop.confirmed_turn is None or prop.confirmed_turn <= prop.created_turn:
                tr.emit("write_denied", proposal=proposal_id, reason="confirmation_not_after_proposal")
                return {"filed": False, "reason": "confirmation must come after the summary was shown"}
            try:
                s.budget.charge_step()
            except BudgetExceeded as e:
                return {"filed": False, "reason": f"budget exceeded ({e.dimension})"}
            # Key is a pure function of (tenant, member, conversation, proposal): any retry, in this
            # process or after a crash, presents the same key and the platform returns the original.
            key = hashlib.sha256(f"{s.tenant}|{s.member_id}|{s.id}|{prop.id}".encode()).hexdigest()[:40]
            client, payload, last = self.p.client(s.tenant), prop.payload(), None
            for attempt in range(1, 5):
                t0 = time.monotonic()
                try:
                    status, body, replayed = client.create_grievance(s.member_id, payload, key)
                    s.budget.add_latency(time.monotonic() - t0)
                    prop.status = EXECUTED
                    prop.result = {"grievance_id": body["grievance_id"], "received_date": body["received_date"],
                                   "category": body["category"], "status": body["status"]}
                    tr.emit("write", tool="file_grievance", proposal=prop.id, attempt=attempt,
                            http=status, replayed=replayed, grievance_id=body["grievance_id"], decision="allow")
                    return {"filed": True, "replay": False, **prop.result}
                except ApiError as e:
                    s.budget.add_latency(time.monotonic() - t0)
                    last = e
                    tr.emit("write_attempt_failed", proposal=prop.id, attempt=attempt, http=e.status)
                    if e.status not in (0, 429, 502, 503, 504):
                        prop.status = FAILED
                        return {"filed": False, "reason": f"rejected by the grievance system ({e.status})"}
                    self._sleep(min(e.retry_after or 0.5 * attempt, 3.0))
            # Still no acknowledgement. The write may or may not have landed: reconcile, never blind-retry.
            try:
                for g in client.grievances(s.member_id):
                    if (g["description"] == payload["description"] and g["category"] == payload["category"]
                            and g.get("received_date") == self.p.as_of):
                        prop.status = EXECUTED
                        prop.result = {"grievance_id": g["grievance_id"], "received_date": g["received_date"],
                                       "category": g["category"], "status": g["status"]}
                        tr.emit("write_reconciled", proposal=prop.id, grievance_id=g["grievance_id"])
                        return {"filed": True, "replay": False, "reconciled": True, **prop.result}
            except ApiError:
                pass
            prop.status = UNKNOWN
            tr.emit("write_unknown", proposal=prop.id, last_http=getattr(last, "status", None))
            return {"filed": False, "reason": "unknown",
                    "message": "The grievance system did not acknowledge. It may or may not be on file. Do not re-file; "
                               "check the member's grievance list or retry confirmation shortly."}
