"""Per-conversation trace: every model call, tool call and gateway decision.

Events are appended to a tenant-partitioned JSONL file and kept in memory. Each event carries the
hash of the previous one (tamper-evident chain; in production the sink is WORM storage with 6-year
retention). Callers pass already-minimised data and `emit` scrubs again as a backstop.
"""
from __future__ import annotations

import hashlib
import json
import threading
import time
from pathlib import Path

from .safety import scrub


def _digest(body: dict) -> str:
    return hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()[:16]


class Trace:
    def __init__(self, conversation_id: str, tenant: str, trace_dir: Path | None, known_sensitive=None):
        self.conversation_id = conversation_id
        self.tenant = tenant
        self.events: list[dict] = []
        self._prev = "0" * 16
        self._lock = threading.Lock()
        self.known_sensitive = known_sensitive if known_sensitive is not None else []
        self._fh = None
        if trace_dir is not None:
            d = Path(trace_dir) / tenant
            d.mkdir(parents=True, exist_ok=True)
            self._fh = open(d / f"{conversation_id}.jsonl", "a", encoding="utf-8")

    def emit(self, type_: str, **data) -> dict:
        safe = json.loads(scrub(json.dumps(data, default=str), self.known_sensitive))
        with self._lock:
            ev = {"seq": len(self.events), "ts": round(time.time(), 3), "type": type_,
                  "conversation_id": self.conversation_id, "tenant": self.tenant, **safe,
                  "prev": self._prev}
            ev["hash"] = _digest(ev)
            self._prev = ev["hash"]
            self.events.append(ev)
            if self._fh:
                self._fh.write(json.dumps(ev) + "\n")
                self._fh.flush()
        return ev

    def verify_chain(self) -> bool:
        prev = "0" * 16
        for ev in self.events:
            body = {k: v for k, v in ev.items() if k != "hash"}
            if body["prev"] != prev or _digest(body) != ev["hash"]:
                return False
            prev = ev["hash"]
        return True

    def close(self):
        if self._fh:
            self._fh.close()
            self._fh = None
