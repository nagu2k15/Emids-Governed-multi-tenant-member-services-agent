"""HTTP API (stdlib). Multi-turn: create a conversation, then post turns; confirmation is just the next turn.

    POST /v1/conversations                 {"member_id": "M123456"}          -> 201 {conversation_id, member_found, ...}
    POST /v1/conversations/{id}/turns      {"text": "..."}                   -> 200 {reply, kind, pending_confirmation, budget}
    POST /v1/conversations/{id}/confirm    {"proposal_id": "..."}            -> explicit UI confirmation (same effect as a 'confirm' turn)
    POST /v1/conversations/{id}/cancel     {}
    GET  /v1/conversations/{id}/trace                                       -> redacted, hash-chained event list
    GET  /healthz

Authentication: `Authorization: Bearer <rep token>`; the token maps to (rep_id, tenant) in MSA_REPS_FILE.
The tenant is NEVER taken from the request: a conversation id from another tenant is simply a 404.
"""
from __future__ import annotations

import json
import re
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .config import Config
from .service import AgentService
from .session import CANCELLED, CONFIRMED, PROPOSED


def load_reps(cfg: Config) -> dict:
    if cfg.reps_file and cfg.reps_file.exists():
        return json.loads(cfg.reps_file.read_text(encoding="utf-8"))
    return {}


def make_handler(svc: AgentService, reps: dict):
    class H(BaseHTTPRequestHandler):
        server_version = "msagent/0.1"

        def _send(self, code, body):
            raw = json.dumps(body).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def _rep(self):
            auth = self.headers.get("Authorization", "")
            rep = reps.get(auth[7:].strip()) if auth.startswith("Bearer ") else None
            if rep is None:
                self._send(401, {"error": "unauthorized"})
            return rep

        def _json(self):
            n = int(self.headers.get("Content-Length") or 0)
            if n > 20_000:
                return None
            try:
                return json.loads(self.rfile.read(n) or b"{}")
            except ValueError:
                return None

        def do_GET(self):
            if self.path == "/healthz":
                return self._send(200, {"status": "ok", "provider": svc.llm.name})
            m = re.fullmatch(r"/v1/conversations/(\w+)/trace", self.path)
            rep = self._rep()
            if rep is None:
                return
            s = m and svc.get(m.group(1), rep["tenant"])
            if not s:
                return self._send(404, {"error": "not_found"})
            self._send(200, {"events": s.trace.events, "chain_valid": s.trace.verify_chain()})

        def do_POST(self):
            rep = self._rep()
            if rep is None:
                return
            body = self._json()
            if body is None:
                return self._send(400, {"error": "bad_request"})
            if self.path == "/v1/conversations":
                mid = body.get("member_id", "")
                if not re.fullmatch(r"M\d{6}", mid):
                    return self._send(422, {"error": "member_id must look like M123456"})
                s = svc.create_conversation(rep["tenant"], rep["rep_id"], mid)
                return self._send(201, {"conversation_id": s.id, "member_found": s.member_status == "ok",
                                        "coverage_status": s.coverage.get("coverage_status")})
            m = re.fullmatch(r"/v1/conversations/(\w+)/(turns|confirm|cancel)", self.path)
            s = m and svc.get(m.group(1), rep["tenant"])      # tenant comes from the token, not the body
            if not s:
                return self._send(404, {"error": "not_found"})
            if m.group(2) == "turns":
                text = body.get("text")
                if not isinstance(text, str) or not text.strip() or len(text) > 2000:
                    return self._send(422, {"error": "text is required (max 2000 characters)"})
                return self._send(200, svc.turn(s, text))
            p = s.proposals.get(body.get("proposal_id", ""))
            if not p or p.status != PROPOSED or p.created_turn >= s.turn_no:
                return self._send(409, {"error": "no confirmable proposal (it must have been shown to the rep first)"})
            with s.lock:
                s.turn_no += 1
                s.trace.emit("confirmation", proposal=p.id, decision=m.group(2), via="api")
                if m.group(2) == "cancel":
                    p.status = CANCELLED
                    return self._send(200, {"reply": "Understood. Nothing was filed.", "kind": "cancelled"})
                reply, kind = svc._confirm(s, p)
            self._send(200, {"reply": reply, "kind": kind})

        def log_message(self, *a):
            pass
    return H


def serve(svc: AgentService, reps: dict, host="127.0.0.1", port=8080):
    httpd = ThreadingHTTPServer((host, port), make_handler(svc, reps))
    print(f"msagent API on http://{host}:{port} (provider={svc.llm.name})", flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    return httpd
