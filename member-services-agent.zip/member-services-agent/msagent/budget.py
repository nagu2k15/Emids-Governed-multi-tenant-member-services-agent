"""Per-conversation budgets for steps, cost and latency, enforced by the gateway and agent loop."""
from __future__ import annotations

import threading
import time

from .config import Budgets


class BudgetExceeded(Exception):
    def __init__(self, dimension: str, detail: str = ""):
        super().__init__(f"{dimension}: {detail}")
        self.dimension = dimension


class Budget:
    def __init__(self, limits: Budgets, price_in: float = 1.0, price_out: float = 5.0):
        self.limits = limits
        self.price_in, self.price_out = price_in, price_out
        self.steps = 0
        self.turn_steps = 0
        self.cost_usd = 0.0
        self.latency_s = 0.0
        self.turn_started = time.monotonic()
        self._lock = threading.Lock()

    def start_turn(self):
        with self._lock:
            self.turn_steps = 0
            self.turn_started = time.monotonic()

    def charge_step(self):
        """Call before every model or tool call; raises BudgetExceeded when any limit is hit."""
        with self._lock:
            l = self.limits
            if self.steps >= l.max_steps_per_conversation:
                raise BudgetExceeded("steps", f"conversation limit {l.max_steps_per_conversation}")
            if self.turn_steps >= l.max_steps_per_turn:
                raise BudgetExceeded("steps", f"turn limit {l.max_steps_per_turn}")
            if self.cost_usd >= l.max_cost_usd:
                raise BudgetExceeded("cost", f"${self.cost_usd:.4f} >= ${l.max_cost_usd}")
            if self.latency_s >= l.max_latency_s:
                raise BudgetExceeded("latency", f"{self.latency_s:.1f}s >= {l.max_latency_s}s")
            if time.monotonic() - self.turn_started >= l.max_turn_latency_s:
                raise BudgetExceeded("latency", f"turn exceeded {l.max_turn_latency_s}s")
            self.steps += 1
            self.turn_steps += 1

    def add_latency(self, seconds: float):
        with self._lock:
            self.latency_s += seconds

    def add_usage(self, input_tokens: int, output_tokens: int) -> float:
        with self._lock:
            c = (input_tokens * self.price_in + output_tokens * self.price_out) / 1e6
            self.cost_usd += c
            return c

    def snapshot(self) -> dict:
        return {"steps": self.steps, "cost_usd": round(self.cost_usd, 6),
                "latency_s": round(self.latency_s, 2)}
