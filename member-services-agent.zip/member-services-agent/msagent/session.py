"""Conversation state. One conversation = one rep, one tenant, one member.

The store is an interface; the slice uses memory. In production this is a tenant-keyed, encrypted
store (DynamoDB / Redis) so any stateless API replica can serve the next turn.
"""
from __future__ import annotations

import threading
import uuid
from dataclasses import dataclass, field

from .budget import Budget
from .trace import Trace

PROPOSED, CONFIRMED, CANCELLED, EXECUTED, UNKNOWN, FAILED = (
    "PROPOSED", "CONFIRMED", "CANCELLED", "EXECUTED", "UNKNOWN", "FAILED")


@dataclass
class Proposal:
    id: str
    category: str
    description: str
    expedite_requested: bool
    expedite_reason: str
    created_turn: int
    status: str = PROPOSED
    confirmed_turn: int | None = None
    result: dict | None = None

    def payload(self) -> dict:
        d = {"category": self.category, "description": self.description,
             "expedite_requested": self.expedite_requested}
        return d

    def view(self) -> dict:
        return {"proposal_id": self.id, "category": self.category, "description": self.description,
                "expedite_requested": self.expedite_requested, "status": self.status}


@dataclass
class Session:
    id: str
    tenant: str
    rep_id: str
    member_id: str
    budget: Budget
    trace: Trace
    member: dict | None = None            # PRIVATE full record: never leaves the gateway
    member_status: str = "unresolved"     # ok | not_found | error
    coverage: dict = field(default_factory=dict)   # minimised, model-visible context
    turn_no: int = 0
    turns: list = field(default_factory=list)      # [{"messages": [...]}]
    proposals: dict = field(default_factory=dict)
    identity_attempts: int = 0
    last_kind: str = ""
    lock: threading.RLock = field(default_factory=threading.RLock)

    def pending(self) -> Proposal | None:
        for p in self.proposals.values():
            if p.status == PROPOSED:
                return p
        return None

    def sensitive_values(self) -> list[str]:
        """Literal values to scrub from anything logged or returned."""
        m = self.member or {}
        a = m.get("address") or {}
        vals = [m.get("first_name"), m.get("last_name"), m.get("dob"), m.get("ssn"), m.get("phone"),
                m.get("email"), a.get("line1")]
        if m.get("first_name") and m.get("last_name"):
            vals.append(f"{m['first_name']} {m['last_name']}")
        return [v for v in vals if v]


class SessionStore:
    def __init__(self):
        self._s: dict[str, Session] = {}
        self._lock = threading.Lock()

    def put(self, s: Session):
        with self._lock:
            self._s[s.id] = s

    def get(self, sid: str, tenant: str) -> Session | None:
        """Tenant is part of the lookup: a conversation id from another tenant simply does not exist."""
        with self._lock:
            s = self._s.get(sid)
        return s if s and s.tenant == tenant else None


def new_id() -> str:
    return uuid.uuid4().hex[:16]
