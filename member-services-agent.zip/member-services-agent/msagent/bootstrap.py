"""Wire everything together from configuration."""
from __future__ import annotations

import json
import urllib.request

from .config import Config
from .gateway import Gateway
from .kb import KnowledgeBase
from .llm.factory import make_llm
from .service import AgentService
from .tools import Platform


def mock_clock(base_url: str) -> str:
    with urllib.request.urlopen(base_url + "/health", timeout=5) as r:
        return json.load(r)["clock"]


def build_platform(cfg: Config) -> Platform:
    kb = KnowledgeBase(cfg.kb_dir)
    names = {}
    tfile = cfg.pack_dir / "mock_services" / "data" / "tenants.json"
    if tfile.exists():
        names = {t: i.get("name", "") for t, i in json.loads(tfile.read_text(encoding="utf-8"))["tenants"].items()}
    as_of = cfg.as_of or mock_clock(cfg.mock_url)
    return Platform(cfg, kb, as_of, names)


def build_service(cfg: Config, llm=None) -> AgentService:
    platform = build_platform(cfg)
    return AgentService(cfg, platform, llm or make_llm(cfg), Gateway(platform))
