"""Configuration. Everything environment-specific comes from env vars (MSA_*)."""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path


def _float(name: str, default: float) -> float:
    return float(os.environ.get(name, default))


def _int(name: str, default: int) -> int:
    return int(os.environ.get(name, default))


@dataclass(frozen=True)
class Budgets:
    """Per-conversation budgets. A step is one model call or one tool call."""
    max_steps_per_conversation: int = 40
    max_steps_per_turn: int = 8
    max_cost_usd: float = 0.10          # hard cap; NFR-7 target average is $0.03
    max_latency_s: float = 120.0        # cumulative time spent in model + tools
    max_turn_latency_s: float = 20.0    # hard stop for one rep question (target p95 is 3 s)

    @classmethod
    def from_env(cls) -> "Budgets":
        return cls(
            _int("MSA_MAX_STEPS", 40), _int("MSA_MAX_STEPS_TURN", 8),
            _float("MSA_MAX_COST_USD", 0.10), _float("MSA_MAX_LATENCY_S", 120.0),
            _float("MSA_MAX_TURN_LATENCY_S", 20.0),
        )


@dataclass
class Config:
    pack_dir: Path
    mock_url: str = "http://127.0.0.1:8090"
    tokens: dict[str, str] = field(default_factory=dict)      # tenant -> bearer token
    directory_key: str = ""
    as_of: str | None = None                                 # YYYY-MM-DD; default: mock /health clock
    provider: str = "rules"                                  # rules | anthropic | openai
    model: str = ""
    llm_base_url: str = ""
    llm_api_key: str = ""
    price_in_per_mtok: float = 1.0                           # ASSUMPTION: configure for your model
    price_out_per_mtok: float = 5.0
    trace_dir: Path = Path("traces")
    audit_key: bytes = b"dev-only-change-me"                 # HMAC key for pseudonymising member ids
    budgets: Budgets = field(default_factory=Budgets)
    prefetch_claims: bool = True
    http_timeout_s: float = 10.0
    claims_cache_ttl_s: float = 300.0
    reps_file: Path | None = None
    fallback_rules: bool = True            # degraded mode: deterministic policy when the model is down

    @property
    def kb_dir(self) -> Path:
        return self.pack_dir / "kb"

    @classmethod
    def from_env(cls) -> "Config":
        pack = Path(os.environ.get("MSA_PACK_DIR", "pack")).expanduser()
        tokens: dict[str, str] = {}
        for k, v in os.environ.items():
            if k.startswith("MSA_TOKEN_"):
                tokens[k[len("MSA_TOKEN_"):].lower()] = v
        dkey = os.environ.get("MSA_DIRECTORY_KEY", "")
        # Dev convenience only: in production secrets come from a secret manager, not the data pack.
        tfile = pack / "mock_services" / "data" / "tenants.json"
        if not tokens and tfile.exists() and os.environ.get("MSA_SECRETS_FROM_PACK", "1") == "1":
            cfg = json.loads(tfile.read_text(encoding="utf-8"))
            tokens = {t: i["api_token"] for t, i in cfg["tenants"].items()}
            dkey = dkey or cfg["directory"]["api_key"]
        provider = os.environ.get("MSA_PROVIDER", "rules").lower()
        key = os.environ.get("MSA_API_KEY") or os.environ.get(
            "ANTHROPIC_API_KEY" if provider == "anthropic" else "OPENAI_API_KEY", "")
        reps = os.environ.get("MSA_REPS_FILE")
        return cls(
            pack_dir=pack,
            mock_url=os.environ.get("MSA_MOCK_URL", "http://127.0.0.1:8090").rstrip("/"),
            tokens=tokens, directory_key=dkey, as_of=os.environ.get("MSA_AS_OF"),
            provider=provider, model=os.environ.get("MSA_MODEL", ""),
            llm_base_url=os.environ.get("MSA_LLM_BASE_URL", ""), llm_api_key=key,
            price_in_per_mtok=_float("MSA_PRICE_IN_PER_MTOK", 1.0),
            price_out_per_mtok=_float("MSA_PRICE_OUT_PER_MTOK", 5.0),
            trace_dir=Path(os.environ.get("MSA_TRACE_DIR", "traces")),
            audit_key=os.environ.get("MSA_AUDIT_KEY", "dev-only-change-me").encode(),
            budgets=Budgets.from_env(),
            prefetch_claims=os.environ.get("MSA_PREFETCH_CLAIMS", "1") == "1",
            reps_file=Path(reps) if reps else None,
            fallback_rules=os.environ.get("MSA_FALLBACK", "1") == "1",
        )
