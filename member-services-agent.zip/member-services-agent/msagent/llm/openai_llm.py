"""OpenAI-compatible chat-completions adapter: OpenAI, Azure OpenAI, vLLM, Ollama (/v1), LiteLLM."""
from __future__ import annotations

import json
import urllib.error
import urllib.request

from .base import LLM, LLMError, LLMResponse, ToolCall, Usage


class OpenAICompatLLM(LLM):
    name = "openai"

    def __init__(self, model: str, api_key: str, base_url: str, timeout: float = 60.0):
        self.model, self.key, self.base, self.timeout = model, api_key, base_url.rstrip("/"), timeout

    def _convert(self, system, messages):
        out = [{"role": "system", "content": system}]
        for m in messages:
            if m["role"] == "user":
                out.append({"role": "user", "content": m["content"]})
            elif m["role"] == "assistant":
                d = {"role": "assistant", "content": m.get("content") or None}
                if m.get("tool_calls"):
                    d["tool_calls"] = [{"id": c["id"], "type": "function",
                                        "function": {"name": c["name"], "arguments": json.dumps(c["args"])}}
                                       for c in m["tool_calls"]]
                out.append(d)
            else:
                out.append({"role": "tool", "tool_call_id": m["tool_call_id"], "content": m["content"]})
        return out

    def complete(self, system, messages, tools) -> LLMResponse:
        body = {"model": self.model, "temperature": 0, "max_tokens": 700,
                "messages": self._convert(system, messages),
                "tools": [{"type": "function", "function": {"name": t["name"], "description": t["description"],
                                                            "parameters": t["input_schema"]}} for t in tools]}
        headers = {"content-type": "application/json"}
        if self.key:
            headers["authorization"] = f"Bearer {self.key}"
        req = urllib.request.Request(self.base + "/chat/completions", data=json.dumps(body).encode(),
                                     method="POST", headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                d = json.load(r)
            msg = d["choices"][0]["message"]
            calls = []
            for c in msg.get("tool_calls") or []:
                try:
                    args = json.loads(c["function"].get("arguments") or "{}")
                except ValueError:
                    args = {"_unparseable": True}      # gateway rejects it: unknown argument
                calls.append(ToolCall(c["id"], c["function"]["name"], args))
        except (urllib.error.URLError, TimeoutError, OSError, ValueError, KeyError, IndexError) as e:
            raise LLMError(f"openai-compatible request failed: {e}")
        u = d.get("usage", {})
        return LLMResponse(msg.get("content") or "", calls,
                           Usage(u.get("prompt_tokens", 0), u.get("completion_tokens", 0)), d.get("model", self.model))
