"""Offline reference policy: a deterministic stand-in for the model.

It speaks the same interface as the real providers (tool calls in, text out), so the gateway, budgets,
confirmation flow, trace and evaluation harness run unchanged with no network model. It is stateless:
each call re-runs the intent logic against the tool results already present in the transcript and either
asks for the next tool call(s) or returns the final answer.

It exists to (a) make CI and the evaluation reproducible and free, (b) prove the platform controls hold
independent of model behaviour, and (c) give a quality baseline for real models to beat. It is NOT a
substitute for an LLM on open-ended phrasing.
"""
from __future__ import annotations

import json
import re

from .base import LLM, LLMResponse, ToolCall


class _Need(Exception):
    def __init__(self, calls):
        self.calls = calls


def _key(name, args):
    return name + json.dumps(args, sort_keys=True)


def money(x) -> str:
    return f"${x:,.2f}"


ISO = r"\d{4}-\d{2}-\d{2}"


class RulesLLM(LLM):
    name = "rules"

    def complete(self, system, messages, tools) -> LLMResponse:
        i = max(k for k, m in enumerate(messages) if m["role"] == "user")
        text = messages[i]["content"]
        results, ids = {}, {}
        for m in messages[i + 1:]:
            if m["role"] == "assistant":
                for tc in m.get("tool_calls", []):
                    ids[tc["id"]] = _key(tc["name"], tc["args"])
            elif m["role"] == "tool":
                results[ids[m["tool_call_id"]]] = json.loads(m["content"])
        n = len(results)

        def R(name, args=None):
            args = args or {}
            if _key(name, args) in results:
                return results[_key(name, args)]
            raise _Need([(name, args)])

        def RR(*calls):
            missing = [(n_, a_ or {}) for n_, a_ in calls if _key(n_, a_ or {}) not in results]
            if missing:
                raise _Need(missing)
            return [results[_key(n_, a_ or {})] for n_, a_ in calls]

        try:
            out = self._respond(text, R, RR)
            return LLMResponse(text=out, model="rules-v1")
        except _Need as nd:
            return LLMResponse(tool_calls=[ToolCall(f"r{n}_{j}", a, b) for j, (a, b) in enumerate(nd.calls)],
                               model="rules-v1")

    # ------------------------------------------------------------------ policy
    def _respond(self, text, R, RR) -> str:
        t = text.lower()
        ctx = R("get_member_context")
        terminated = ctx.get("coverage_status") == "TERMINATED"
        claim_id = (re.search(r"\bC\d{10}\b", text) or [None])[0] if re.search(r"\bC\d{10}\b", text) else None
        gid = re.search(r"\bG\d{2}-\d+\b", text)
        dates = re.findall(ISO, text)
        year = 2027 if re.search(r"january 1|renew|next (plan )?year|2027|after that|new plan year", t) else None

        # ---- identity / SSN
        if re.search(r"\bssn\b|social security|\bsocial\b", t):
            last4 = re.search(r"\b(\d{4})\b", re.sub(ISO, "", text))
            if last4 and re.search(r"last (four|4)", t):
                r = R("verify_identity", {"ssn_last4": last4.group(1)})
                if r.get("locked"):
                    return r["message"]
                return ("The last four SSN digits match the record on file." if r["ssn_last4_match"]
                        else "The last four SSN digits do not match the record on file. Do not proceed with account changes.")
            return ("I can't read out or display a member's Social Security number. To verify the caller, ask for the "
                    "last four digits and I'll check them against the record, along with date of birth.")
        if re.search(r"date of birth|\bdob\b|birthday", t) and dates:
            r = R("verify_identity", {"dob": dates[0]})
            if r.get("locked"):
                return r["message"]
            return "The date of birth matches the record on file." if r["dob_match"] else \
                "The date of birth does not match the record on file."

        # ---- grievance deadline / status
        if gid:
            r = R("check_deadline", {"kind": "grievance", "reference_id": gid.group(0)})
            if not r["found"]:
                return f"I can't find grievance {gid.group(0)} for this member."
            if r["status"] == "RESOLVED":
                return (f"No - grievance {r['grievance_id']} was resolved on {r['resolved_date']}. "
                        f"(Plan timeframe: {r['resolution_days']} calendar days from {r['received_date']}, "
                        f"i.e. {r['deadline']}.)")
            word = "Yes" if r["past_deadline"] else "No"
            return (f"{word} - grievance {r['grievance_id']} (status {r['status']}) was received {r['received_date']}; the plan "
                    f"resolves grievances within {r['resolution_days']} calendar days, so the deadline is {r['deadline']}. "
                    f"As of {r['as_of']} it is {'past' if r['past_deadline'] else 'not past'} that deadline"
                    + (f" ({-r['days_remaining']} days over)." if r["past_deadline"] else f" ({r['days_remaining']} days left)."))

        # ---- prior authorization (system of record is elsewhere)
        if re.search(r"prior auth|precert|pre-auth|authorization", t) and re.search(r"approv|status|decision|been|pending", t) \
                and not claim_id and "appeal" not in t:
            return ("That information isn't available to me. Prior authorization requests and decisions are handled by the "
                    "Utilization Management team in a separate system, so I can't tell you whether it has been approved. "
                    "Please check with that team.")

        # ---- grievance filing (propose only; filing needs the rep's confirmation in the next message)
        if re.search(r"\b(file|submit|open|log|lodge|raise|start)\b", t) and re.search(r"grievance|complaint", t):
            cat = self._category(t)
            desc = self._describe(text)
            r = R("propose_grievance", {"category": cat, "description": desc})
            msg = f"I've drafted a {cat.replace('_', ' ')} grievance. It has NOT been filed yet."
            if r.get("possible_duplicate_of"):
                msg += f" Note: this member already has an open {cat} grievance ({', '.join(r['possible_duplicate_of'])})."
            return msg

        # ---- claims
        if "appeal" in t:
            cid = claim_id
            if not cid:
                s = R("search_claims", {"status": "DENIED"})
                if s["total_matching"] != 1:
                    return "Which claim is the member appealing? Please give me the claim number."
                cid = s["claims"][0]["claim_id"]
            r = R("check_deadline", {"kind": "appeal", "reference_id": cid})
            if not r["found"]:
                return f"I can't find claim {cid} for this member."
            if not r["applicable"]:
                return f"Claim {cid} is {r['claim_status']}, not denied, so there is no appeal window."
            word = "Yes" if r["within_window"] else "No"
            tail = (f"{r['days_remaining']} days remain." if r["within_window"] else
                    f"the window closed {-r['days_remaining']} days ago.")
            return (f"{word} - claim {cid} was denied (denial notice date {r['denial_notice_date']}). The plan allows "
                    f"{r['window_days']} calendar days from the notice, so the appeal deadline is {r['deadline']}; as of "
                    f"{r['as_of']}, {tail}")

        if claim_id:
            r = R("get_claim", {"claim_id": claim_id})
            if not r["found"]:
                return f"I can't find claim {claim_id} for this member."
            return self._claim_text(r["claim"], R)

        if re.search(r"how many", t) and re.search(r"claim", t) and re.search(r"denied|denial", t):
            y = (re.search(r"\b(20\d\d)\b", t) or [None, "2026"])[1]
            r = R("search_claims", {"status": "DENIED", "date_from": f"{y}-01-01", "date_to": f"{y}-12-31"})
            lst = "; ".join(f"{c['claim_id']} ({c['service_date']}, {c['denial']['carc']})" for c in r["claims"])
            return f"{r['total_matching']} of the member's {y} claims were denied: {lst}."

        if dates and re.search(r"claim|denied|owe|bill|visit|mri|x-ray|session|lab|what happened", t) and not re.search(r"birth|dob", t):
            r = R("search_claims", {"service_date": dates[0]})
            if r["total_matching"] == 0:
                return f"I don't see any claims with a service date of {dates[0]} for this member."
            parts = [self._claim_text(c, R) for c in r["claims"][:3]]
            return "\n".join(parts)

        # ---- accumulators
        if re.search(r"deductible|out-of-pocket|out of pocket|\boop\b|physical therapy|\bpt\b", t) and not (
                terminated and not re.search(r"claim", t)):
            remain = re.search(r"left|remain|still|before|more|meet|far|away|until|reach|use", t)
            if re.search(r"physical therapy|\bpt\b", t) and remain:
                a = R("get_accumulators")
                pt = a.get("physical_therapy")
                if pt:
                    return (f"{pt['remaining']} physical therapy visits remain for plan year {a['plan_year']} "
                            f"({pt['used']} of {pt['limit']} used).")
            elif re.search(r"out-of-pocket|out of pocket|\boop\b", t):
                a = R("get_accumulators")
                o = a.get("out_of_pocket_max")
                if o:
                    if "family" in t:
                        return (f"The family in-network out-of-pocket maximum is {money(o['family_limit']).replace('.00', '')} "
                                f"({a['product']}, plan year {a['plan_year']}); the individual maximum is {money(o['limit']).replace('.00', '')}.")
                    if remain:
                        return (f"The member has {money(o['remaining'])} left to reach the individual in-network out-of-pocket "
                                f"maximum of {money(o['limit'])} ({money(o['met'])} met so far, plan year {a['plan_year']}).")
                    return (f"Individual in-network out-of-pocket maximum is {money(o['limit'])}; {money(o['met'])} met "
                            f"(plan year {a['plan_year']}).")
            elif "deductible" in t and (remain or re.search(r"how much", t)) and "family" not in t:
                a = R("get_accumulators")
                d = a.get("deductible")
                if d:
                    return (f"The member still has {money(d['remaining'])} to meet on the individual in-network deductible "
                            f"of {money(d['limit'])} ({money(d['met'])} met so far, plan year {a['plan_year']}).")

        # ---- provider search
        if re.search(r"find|look for|search|nearby|near", t) and re.search(
                r"dermatolog|cardiolog|endocrin|gastro|orthop|physical therap|behavioral|family medicine|provider|doctor", t) \
                and not terminated:
            spec = self._specialty(t)
            if spec:
                r = R("find_providers", {"specialty": spec})
                if not r["providers"]:
                    return f"I found no in-network {spec} providers near the member's ZIP area."
                lines = [f"- {p['name']}, {p['practice']}, {p['city']} {p['zip']}, {p['phone']}"
                         f"{'' if p['accepting_new_patients'] else ' (not accepting new patients)'}" for p in r["providers"]]
                return f"In-network {spec} providers near the member's home ZIP area ({r['network']}):\n" + "\n".join(lines)

        # ---- benefits
        if terminated:
            return (f"The member's coverage is not active: it ended on {ctx['coverage_termination']}, so I can't quote "
                    f"current benefits. Claims for services after that date deny with CARC 27.")
        r = R("search_plan_docs", {"query": text, "plan_year": year} if year else {"query": text})
        hits = r["results"]
        if not hits or hits[0]["score"] < 4.0:
            return ("I don't have that information in the plan documents or the member's record, so I can't answer "
                    "without guessing.")
        top = hits[0]
        pre = f"The member is enrolled in {ctx['plan_name']}. " if re.search(r"which plan|what plan|enrolled", t) else ""
        if top["text"].startswith("Benefit:"):
            m = re.match(r"Benefit: (.*?); In-network member cost: (.*?); Out-of-network member cost: (.*)$", top["text"])
            if m:
                return (f"{pre}{top['product']}, plan year {top['plan_year']} - {m.group(1)}: in-network {m.group(2)}"
                        f" (out-of-network: {m.group(3)}).")
        return f"{pre}{top['product']} plan documents (plan year {top['plan_year']}): {top['text']}"

    # ------------------------------------------------------------------ helpers
    def _category(self, t):
        for c, pat in (("billing", r"billing grievance|\bbill|charge|balance|invoice"),
                       ("quality_of_care", r"quality|care was|treatment|misdiagnos|discharged"),
                       ("access", r"access|appointment|wait for|network|referral"),
                       ("customer_service", r"customer service|rude|on hold|id card|call back")):
            if re.search(pat, t):
                return c
        return "other"

    def _describe(self, text):
        sents = re.split(r"(?<=[.!?])\s+", text.strip())
        keep = [s for s in sents if not re.search(r"^(please|can you|could you|go ahead)|file it\b|^yes\b", s.strip(), re.I)]
        d = " ".join(keep) or text
        return re.sub(r"^(the )?member (wants|would like) to file an? [a-z ]*grievance:?\s*", "", d, flags=re.I)[:1900]

    def _specialty(self, t):
        for k, v in (("dermatolog", "Dermatology"), ("cardiolog", "Cardiology"), ("endocrin", "Endocrinology"),
                     ("gastro", "Gastroenterology"), ("orthop", "Orthopedic Surgery"), ("physical therap", "Physical Therapy"),
                     ("behavioral", "Behavioral Health"), ("family medicine", "Family Medicine"), ("primary care", "Family Medicine")):
            if k in t:
                return v
        return None

    def _claim_text(self, c, R) -> str:
        o = c["member_owes"]
        head = f"Claim {c['claim_id']} ({c['service']}, service date {c['service_date']}): status {c['status']}."
        if c["status"] == "DENIED":
            d = c["denial"]
            why = ""
            r = R("search_plan_docs", {"query": d["carc"]})
            for h in r["results"]:
                m = re.search(r"CARC: " + re.escape(d["carc"]) + r";.*?What to tell the member: (.*)$", h["text"])
                if m:
                    why = " " + m.group(1)
                    break
            return (f"{head} Denial reason {d['carc']}: {d['description']}{why} Plan paid {money(c['plan_paid'])}; "
                    f"member owes {money(o['total'])} on this claim per the claim record.")
        if c["status"] in ("IN_PROCESS", "PENDED"):
            kinds = {"IN_PROCESS": "received but not yet adjudicated", "PENDED": "on hold, usually waiting for information"}
            notes = [n for n in c["notes"] if not n["text"].startswith("[text withheld")]
            msg = f"{head} It is {kinds[c['status']]}."
            if notes:
                msg += " Notes: " + " ".join(f"{n['text']} ({n['date']})" for n in notes)
            if c.get("notes_warning"):
                msg += " One provider-portal note was withheld because it contained instructions rather than claim facts; I did not act on it."
            return msg
        parts = [f"{k} {money(o[k])}" for k in ("deductible", "copay", "coinsurance") if o[k]]
        return (f"{head} Plan paid {money(c['plan_paid'])}; the member owes {money(o['total'])}"
                + (f" ({', '.join(parts)})." if parts else "."))
