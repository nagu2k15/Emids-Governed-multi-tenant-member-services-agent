from __future__ import annotations

from ..config import Config
from .base import LLM, FallbackLLM


def make_llm(cfg: Config) -> LLM:
    llm = _make(cfg)
    if cfg.provider == "rules" or not cfg.fallback_rules:
        return llm
    from .rules import RulesLLM
    return FallbackLLM(llm, RulesLLM())


def _make(cfg: Config) -> LLM:
    p = cfg.provider
    if p == "rules":
        from .rules import RulesLLM
        return RulesLLM()
    if p == "anthropic":
        from .anthropic_llm import AnthropicLLM
        return AnthropicLLM(cfg.model or "claude-haiku-5-5", cfg.llm_api_key, cfg.llm_base_url or "https://api.anthropic.com")
    if p in ("openai", "ollama"):
        from .openai_llm import OpenAICompatLLM
        base = cfg.llm_base_url or ("http://localhost:11434/v1" if p == "ollama" else "https://api.openai.com/v1")
        return OpenAICompatLLM(cfg.model or ("llama3.1" if p == "ollama" else "gpt-4.1-mini"), cfg.llm_api_key, base)
    raise ValueError(f"unknown MSA_PROVIDER '{p}' (rules | anthropic | openai | ollama)")
