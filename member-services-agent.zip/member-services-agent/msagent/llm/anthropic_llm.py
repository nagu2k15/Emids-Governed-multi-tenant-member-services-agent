"""Anthropic Messages API adapter (stdlib HTTP). Works with any Anthropic-compatible endpoint."""
from __future__ import annotations

import json
import urllib.error
import urllib.request

from .base import LLM, LLMError, LLMResponse, ToolCall, Usage


class AnthropicLLM(LLM):
    name = "anthropic"

    def __init__(self, model: str, api_key: str, base_url: str = "https://api.anthropic.com", timeout: float = 30.0):
        self.model, self.key, self.base, self.timeout = model, api_key, base_url.rstrip("/"), timeout

    def _convert(self, messages):
        out = []
        for m in messages:
            if m["role"] == "user":
                out.append({"role": "user", "content": m["content"]})
            elif m["role"] == "assistant":
                blocks = [{"type": "text", "text": m["content"]}] if m.get("content") else []
                blocks += [{"type": "tool_use", "id": c["id"], "name": c["name"], "input": c["args"]}
                           for c in m.get("tool_calls", [])]
                out.append({"role": "assistant", "content": blocks or [{"type": "text", "text": "(no text)"}]})
            else:  # tool result -> user turn; merge consecutive results into one message
                blk = {"type": "tool_result", "tool_use_id": m["tool_call_id"], "content": m["content"]}
                if out and out[-1]["role"] == "user" and isinstance(out[-1]["content"], list):
                    out[-1]["content"].append(blk)
                else:
                    out.append({"role": "user", "content": [blk]})
        return out

    def complete(self, system, messages, tools) -> LLMResponse:
        body = {"model": self.model, "max_tokens": 700, "temperature": 0,
                "system": [{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
                "tools": [{"name": t["name"], "description": t["description"], "input_schema": t["input_schema"]}
                          for t in tools],
                "messages": self._convert(messages)}
        req = urllib.request.Request(self.base + "/v1/messages", data=json.dumps(body).encode(), method="POST",
                                     headers={"content-type": "application/json", "x-api-key": self.key,
                                              "anthropic-version": "2023-06-01"})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                d = json.load(r)
        except (urllib.error.URLError, TimeoutError, OSError, ValueError) as e:
            raise LLMError(f"anthropic request failed: {e}")
        text = "".join(b.get("text", "") for b in d.get("content", []) if b["type"] == "text")
        calls = [ToolCall(b["id"], b["name"], b.get("input") or {}) for b in d.get("content", []) if b["type"] == "tool_use"]
        u = d.get("usage", {})
        return LLMResponse(text, calls, Usage(u.get("input_tokens", 0) + u.get("cache_read_input_tokens", 0)
                                              + u.get("cache_creation_input_tokens", 0), u.get("output_tokens", 0)),
                           d.get("model", self.model))
