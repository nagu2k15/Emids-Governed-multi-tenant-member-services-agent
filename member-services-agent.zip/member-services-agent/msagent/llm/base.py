"""Provider-neutral model interface.

Messages (neutral format, converted per provider by the adapters):
  {"role": "user", "content": str}
  {"role": "assistant", "content": str, "tool_calls": [{"id", "name", "args"}]}
  {"role": "tool", "tool_call_id": str, "name": str, "content": str}
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ToolCall:
    id: str
    name: str
    args: dict


@dataclass
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0


@dataclass
class LLMResponse:
    text: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    usage: Usage = field(default_factory=Usage)
    model: str = ""
    degraded: bool = False     # True when a fallback policy answered because the primary model failed


class LLM:
    name = "base"

    def complete(self, system: str, messages: list[dict], tools: list[dict]) -> LLMResponse:
        raise NotImplementedError


class LLMError(Exception):
    pass


class FallbackLLM(LLM):
    """Degraded mode (ADR-5): if the primary model errors, answer with the deterministic reference policy
    instead of failing. Every governance control (gateway, confirmation, budgets) is unchanged."""

    def __init__(self, primary: LLM, fallback: LLM):
        self.primary, self.fallback = primary, fallback
        self.name = f"{primary.name}+fallback"

    def complete(self, system, messages, tools):
        try:
            return self.primary.complete(system, messages, tools)
        except LLMError:
            r = self.fallback.complete(system, messages, tools)
            r.degraded = True
            return r
